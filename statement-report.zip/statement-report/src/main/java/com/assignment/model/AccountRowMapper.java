package com.assignment.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;


/**
* The AccountRowMapper class to injects the Resultset data while work with springJDBC
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public class AccountRowMapper implements RowMapper<Account>{

	public static final Logger logger = LoggerFactory.getLogger(AccountRowMapper.class);
	
	@Override
	public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
		Account account = new Account();
		try {
			account.setId(rs.getLong("ID"));
			account.setAccountType(rs.getString("account_type"));
			account.setAccountNumber(rs.getString("account_number"));
		}catch(Exception e) {
			logger.error("Error while stting account resultset:",e);
		}
		return account;
	}

}
