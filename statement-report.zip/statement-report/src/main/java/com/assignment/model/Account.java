package com.assignment.model;

/**
* The Account model class to map the data of account table
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public class Account {

    private long id;
    private String accountType;
    private String accountNumber;
    
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

}
