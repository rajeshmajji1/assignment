package com.assignment.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.assignment.model.Statement;

/**
* The StatementRowMapper class to injects the Resultset data while work with springJDBC
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public class StatementRowMapper implements RowMapper<Statement>{

	public static final Logger logger = LoggerFactory.getLogger(StatementRowMapper.class);

	@Override
	public Statement mapRow(ResultSet rs, int rowNum) throws SQLException {
		Statement statement = new Statement();
		try {
			statement.setId(rs.getLong("ID"));
			statement.setAccountId(rs.getLong("account_id"));
			statement.setDate(rs.getString("datefield"));
			statement.setAmount(rs.getString("amount"));
		}catch(Exception e) {
			logger.error("Error while setting statement resultset:",e);
		}
		return statement;
	}

}
