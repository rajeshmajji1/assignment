package com.assignment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.dao.AccountDAO;
import com.assignment.model.Account;

/**
* The AccountServiceImpl class to provide service method definition to get account details
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	AccountDAO accountDAO;
	
	@Override
	public Account findByAccountNumber(String accountNumber) {
		
		return accountDAO.findByAccountNumber(accountNumber);
	}

}
