package com.assignment.service;

import java.util.List;

import com.assignment.model.Statement;

/**
* The StatementService interface to provide service method definition to get statement report
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public interface StatementService {
	public List<Statement> findByFromDateAndToDate(long accountId,String fromDate,String toDate);
	public List<Statement> findByFromAmountAndToAmount(long accountId,String fromAmount,String toAmount);
}
