package com.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.dao.StatementDAO;
import com.assignment.model.Statement;

/**
* The StatementService class to provide service method declaration to get statement report
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
@Service
public class StatementServiceImpl implements StatementService{
	
	@Autowired
	private StatementDAO statementDAO;
	
	@Override
	public List<Statement> findByFromDateAndToDate(long accountId, String fromDate, String toDate) {
		return statementDAO.findByFromDateAndToDate(accountId, fromDate, toDate);
	}

	@Override
	public List<Statement> findByFromAmountAndToAmount(long accountId, String fromAmount, String toAmount) {
		return statementDAO.findByFromAmountAndToAmount(accountId, fromAmount, toAmount);
	}

}
