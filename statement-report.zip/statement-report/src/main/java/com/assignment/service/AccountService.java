package com.assignment.service;

import com.assignment.model.Account;

/**
* The AccountService interface to provide service method declaration to get account details
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public interface AccountService {
	public Account findByAccountNumber(String accountNumber);
}
