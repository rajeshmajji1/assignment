package com.assignment.dao;

import java.util.List;

import com.assignment.model.Statement;

/**
* The StatementDAO interface provides the method declaration to get statement report
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public interface StatementDAO {
	
	public List<Statement> findByFromDateAndToDate(long accountId,String fromDate,String toDate);
	public List<Statement> findByFromAmountAndToAmount(long accountId,String fromAmount,String toAmount);

}
