package com.assignment.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.assignment.model.Account;
import com.assignment.utils.MaskAccountNumber;

/**
* The AccountDAOImpl class provides the method definition to get account details 
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
@Transactional
@Repository
public class AccountDAOImpl implements AccountDAO{
	
	public static final Logger logger = LoggerFactory.getLogger(AccountDAOImpl.class);
	
	@Autowired
	private JdbcTemplate template;
	
	@Override
	public Account findByAccountNumber(String accountNumber) {
		String query = "select * from account where account_number=?";
		Account account = new Account();
		try{
			RowMapper<Account> rowMapper = new BeanPropertyRowMapper<Account>(Account.class);
			account = template.queryForObject(query, rowMapper, accountNumber);
		}catch(EmptyResultDataAccessException e){
			logger.error("Error while querying account details cause account number not found for account:"+MaskAccountNumber.maskAccountNumber(accountNumber),e);
		}catch(Exception e) {
			logger.error("Error while querying account details for account:"+MaskAccountNumber.maskAccountNumber(accountNumber),e);
		}
		return account;
	}

}
