package com.assignment.dao;

import com.assignment.model.Account;

/**
* The AccountDAO interface provides the method declaration to get account details 
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public interface AccountDAO {
	public Account findByAccountNumber(String accountNumber);
}
