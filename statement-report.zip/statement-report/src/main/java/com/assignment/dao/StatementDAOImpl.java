package com.assignment.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.assignment.model.Statement;
import com.assignment.model.StatementRowMapper;
import com.assignment.utils.Constants;
import com.assignment.utils.DatePattern;

/**
* The StatementDAOImpl class provides the method definition to get statement report 
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
@Transactional
@Repository
public class StatementDAOImpl implements StatementDAO{
	
	public static final Logger logger = LoggerFactory.getLogger(StatementDAOImpl.class);
	
	@Autowired
	private JdbcTemplate template;
	
	/**
	   * This findByFromDateAndToDate DAO method is used to get statement report.
	   * when from date and to date are null then it will return 3 months of statement 
	   * @param accountNumber This is the first parameter to the method
	   * @param fromDate  This is the second parameter to the method
	   * @param toDate This is the second parameter to the method
	   * @return statement list
	   */
	@Override
	public List<Statement> findByFromDateAndToDate(long accountId, String fromDate, String toDate){
		
		String query="select * from statement where account_id=? and (datefield>? and datefield<?)";
		List<Statement> statementList=null;
		
		try {
			
			if(fromDate!=null && toDate!=null) {
				fromDate = DatePattern.convertDatePattern(fromDate);
				toDate = DatePattern.convertDatePattern(toDate);
			}else {
				Date date;
				DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
				Calendar cal = Calendar.getInstance();
				date = cal.getTime();  
		        toDate = dateFormat.format(date); //today's date
		        cal.add(Calendar.MONTH, Constants.STATEMENT_MONTHS);
		        date = cal.getTime();
		        fromDate = dateFormat.format(date); //3 months back date
			}
			
			logger.info("fetching the statement for the accountId:"+accountId+" and for the dates:"+fromDate+" and "+toDate);
	        RowMapper<Statement> rowMapper = new StatementRowMapper();
	        statementList = template.query(query,rowMapper,accountId,fromDate,toDate);
	        logger.info("statement-"+statementList);
	        
		}catch(EmptyResultDataAccessException e){
			logger.error("Error while querying statement details:",e);
		}
		return statementList;
	}
	
	/**
	   * This findByFromAmountAndToAmount DAO method is used to get statement report.
	   * it returns statement by taking amount range
	   * @param accountNumber This is the first parameter to the method
	   * @param fromAmount  This is the second parameter to the method
	   * @param toAmount This is the second parameter to the method
	   * @return statement list
	   */
	@Override
	public List<Statement> findByFromAmountAndToAmount(long accountId, String fromAmount, String toAmount) {
		
		String query = "select * from statement where account_id=? and (amount>? and amount<?)";
		List<Statement> statementList = null;
		try{
			
			logger.info("fetching the statement for the accountId:"+accountId+" and for the Amount range:"+fromAmount+" and "+toAmount);
			RowMapper<Statement> rowMapper = new StatementRowMapper();
	        statementList = template.query(query,rowMapper,accountId,fromAmount,toAmount);
	        logger.info("statement-"+statementList);
			return statementList;
		}catch(EmptyResultDataAccessException e){
			logger.error(e.getMessage());
		}
		return statementList;
	}

}
