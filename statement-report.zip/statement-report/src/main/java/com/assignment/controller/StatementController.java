package com.assignment.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.assignment.model.Account;
import com.assignment.model.Statement;
import com.assignment.service.AccountService;
import com.assignment.service.StatementService;
import com.assignment.utils.MaskAccountNumber;
import com.assignment.utils.StringUtils;

/**
* The StatementController program provides the Services to statementReport services
* returns statement list
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
@Controller
@RequestMapping("/statement")
public class StatementController {
	
	public static final Logger logger = LoggerFactory.getLogger(StatementController.class);
	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private StatementService statementService;
	
	/**
	   * This method is used to get statement report. 
	   * @param accountNumber This is the first parameter to the method
	   * @param fromDate  This is the second parameter to the method
	   * @param toDate This is the second parameter to the method
	   * @return statement list
	   */
	@RequestMapping(value="/statement-report", method=RequestMethod.GET)
	public ModelAndView getStatement(
			@RequestParam(name = "accountNumber", required = true) String accountNumber,
            @RequestParam(name = "fromDate",required = false) String fromDate ,
                                        @RequestParam(name = "toDate", required = false) String toDate){
		
		ModelAndView model = new ModelAndView();
		List<Statement> statementList = null;
		try {
			
			StringUtils.isEmpty(accountNumber);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			logger.info("Requesting Statement for the account: "+MaskAccountNumber.maskAccountNumber(accountNumber)+" by User: "+auth.getName()+" For Dates "+fromDate+" and "+toDate);
			Account account = accountService.findByAccountNumber(accountNumber);
			statementList = statementService.findByFromDateAndToDate(account.getId(), fromDate, toDate);

			model.addObject("accountNumber",MaskAccountNumber.maskAccountNumber(accountNumber));
			model.addObject("accountType",account.getAccountType());
			model.addObject("statementList", statementList);
			model.setViewName("statement_list");
		}catch(Exception e) {
			logger.error("Error while fetching statement ",e);
			model.addObject("message",e.getMessage());
			model.addObject("exception",e);
			model.setViewName("custom_error");
		}
		return model;
	}
	/**
	   * This method is used to get statement report. 
	   * @param accountNumber This is the first parameter to the method
	   * @param fromAmount  This is the second parameter to the method
	   * @param toAmountThis is the second parameter to the method
	   * @return statement list
	   */
	@RequestMapping(value="/statement-report-amountrange", method=RequestMethod.GET)
	public ModelAndView getStatementByAmountRange(
            @RequestParam(name = "accountNumber", required = true) String accountNumber,
            @RequestParam(name = "fromAmount", required = true) String fromAmount,
                                        @RequestParam(name = "toAmount",required = true) String toAmount){
		
		ModelAndView model = new ModelAndView();
		List<Statement> statementList = null;
		try {
		
			StringUtils.isEmpty(accountNumber);
			StringUtils.isEmpty(fromAmount);
			StringUtils.isEmpty(toAmount);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			logger.info("Requesting Statement for the account: "+MaskAccountNumber.maskAccountNumber(accountNumber)+" by User: "+auth.getName()+"For Amount range "+fromAmount+" and "+toAmount);
			Account account = accountService.findByAccountNumber(accountNumber);
		
			model.addObject("accountNumber",MaskAccountNumber.maskAccountNumber(accountNumber));
			model.addObject("accountType",account.getAccountType());
			model.addObject("statementList", statementList);
			model.setViewName("statement_list");
		}catch(Exception e) {
			logger.error("Error while fetching statement for account:"+MaskAccountNumber.maskAccountNumber(accountNumber),e);
			model.addObject("message",e.getMessage());
			model.addObject("exception",e);
			model.setViewName("custom_error");
		}
		return model;
	}
		
}
