package com.assignment.utils;

/**
* The Constants class to define constant values to avoide hard coding the classes
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public class Constants {
	
	public static final int ENDLENGTH=4;
	public static final int STATEMENT_MONTHS=-3;
}
