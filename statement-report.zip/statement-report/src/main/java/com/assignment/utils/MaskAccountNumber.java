package com.assignment.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
* The MaskAccountNumber class having method which returns masked account number 
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public class MaskAccountNumber {
	
	public static final Logger logger = LoggerFactory.getLogger(MaskAccountNumber.class);
	
	public static String maskAccountNumber(String accountNumber) {
		String maskedAccountNumber = null;
		try {

		    int maskedLength = accountNumber.length()-Constants.ENDLENGTH;
		    StringBuilder sb = new StringBuilder();
		    for (int i = 0; i < maskedLength; i++) {
		        sb.append("*");
		    }
		   maskedAccountNumber = sb + accountNumber.substring(maskedLength, accountNumber.length());
		}catch(Exception e) {
			logger.error("Error while masking account number",e);

		}
		    return maskedAccountNumber;
	}
}
