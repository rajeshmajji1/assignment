package com.assignment.utils;

/**
* The StringUtils class having method which throws exception when string is null
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public class StringUtils {
	public static boolean isEmpty(String string) throws Exception{
		if(string == null || string.trim().isEmpty()) {
			throw new Exception("Object can not be null");
		}
		return true;
	}
}
