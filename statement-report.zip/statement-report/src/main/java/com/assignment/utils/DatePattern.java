package com.assignment.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
* The DatePattern class will have method takes String formatted date and converts into dd.MM.yyyy and return string value
*
* @author  Rajesh Majji
* @version 1.0
* @since   31/08/2020 
*/
public class DatePattern {
	
	public static final Logger logger = LoggerFactory.getLogger(DatePattern.class);
	public static String convertDatePattern(String date) {
		
		String stringConvertedDate=null;
		try {
			
			Date dateToBeCoverted = new SimpleDateFormat("yyyy-MM-dd").parse(date);
			DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			stringConvertedDate = dateFormat.format(dateToBeCoverted);
			
		}catch(Exception e) {
			logger.error("Error while converting date format to dd.MM.yyyy ",e);
		}
		return stringConvertedDate;
	}
}
