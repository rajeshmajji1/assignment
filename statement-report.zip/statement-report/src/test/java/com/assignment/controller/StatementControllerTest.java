package com.assignment.controller;

import java.lang.reflect.InvocationTargetException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.View;

import com.assignment.model.Statement;
import com.assignment.service.StatementService;
import com.assignment.service.StatementServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration
public class StatementControllerTest {
	
	@InjectMocks
	StatementController controller = new StatementController();
	
	@Mock
	StatementService statementService = new StatementServiceImpl();
	
	@Mock
	View mockView;
	
	MockMvc mockMvc;
	
	Statement statement = new Statement();
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).setSingleView(mockView).build();
	}
	@Test
	public void testStatementReport() throws IllegalArgumentException, InvocationTargetException, Exception {
		/*List<Statement> statementList = Arrays.asList(statement);
		when(statementService.findByFromDateAndToDate(1,"31.05.2020","31.08.2020")).thenReturn(statementList);
		mockMvc.perform(get("statement/statement-report")).andExpect(status().isOk())
		.andExpect(model().attribute("Statements", expectedPeople)).andExpect(view().name("Statements")); */
	}
}