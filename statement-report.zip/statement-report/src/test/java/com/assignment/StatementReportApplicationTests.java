package com.assignment;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.assignment.dao.StatementDAO;
import com.assignment.model.Statement;
import com.assignment.service.StatementService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StatementReportApplicationTests {

	@Autowired
	private StatementService statementService;

	@MockBean
	private StatementDAO statementDAO;

	@Test
	public void getStatementTest() {
		/*when(statementDAO.findByFromDateAndToDate(1,"31.05.2020","31.08.2020")).thenReturn(Stream
				.of(new Statement(61,1,"31.07.2012","828.245746980652")).collect(Collectors.toList()));
		assertEquals(1, statementService.findByFromDateAndToDate(1,"29.04.2020","22.05.2020").size()); */
	}

}
