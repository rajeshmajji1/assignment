package com.assignment.dao;

import com.assignment.model.Statement;
import com.assignment.model.StatementRowMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class StatementDAOImplTest {

    @InjectMocks
    private StatementDAOImpl statementDAO;

    @Mock
    private JdbcTemplate template;

    @Test
    public void test_findByFromDateAndToDate(){
        List<Statement> statements = new ArrayList<>();
        statements.add(new Statement(48,1,"03.03.2012","373.950606558506"));
        statements.add(new Statement(85,1,"04.05.2012","289.279082576802"));
        statements.add(new Statement(94,1,"04.07.2012", "113.405299633134"));
        Mockito.when(template.query(anyString(), any(StatementRowMapper.class),anyVararg())).thenReturn(statements);
        List<Statement> actualResults =  statementDAO.findByFromDateAndToDate(1, "2020-08-01","2020-08-04");
        Assert.assertEquals(3, actualResults.size());
        Mockito.verify(template,Mockito.times(1)).query(anyString(), any(StatementRowMapper.class),anyVararg());
    }

  /*  @Test
    public void test_find3MonthsStatement(){
        List<Statement> statements = new ArrayList<>();
        statements.add(new Statement());
        Mockito.when(template.query(anyString(), any(StatementRowMapper.class),anyVararg())).thenReturn(statements);
        List<Statement> actualResults =  statementDAO.find3MonthsStatement(1l);
        Assert.assertEquals(1, actualResults.size());
        Mockito.verify(template,Mockito.times(1)).query(anyString(), any(StatementRowMapper.class),anyVararg());
    } 


    @Test
    public void test_findByFromAmountAndToAmount(){
        List<Statement> statements = new ArrayList<>();
        statements.add(new Statement());
        Mockito.when(template.query(anyString(), any(StatementRowMapper.class),anyVararg())).thenReturn(statements);
        List<Statement> actualResults =  statementDAO.findByFromAmountAndToAmount(1l, "2000","3000");
        Assert.assertEquals(1, actualResults.size());
        Mockito.verify(template,Mockito.times(1)).query(anyString(), any(StatementRowMapper.class),anyVararg());
    }

    @Test
    public void testNegativeCase_NullResults(){
        Mockito.when(template.query(anyString(), any(StatementRowMapper.class),anyVararg())).thenThrow(new EmptyResultDataAccessException(1));
        List<Statement> actualResults =  statementDAO.findByFromAmountAndToAmount(1l, "2000","3000");
        Assert.assertEquals(null,actualResults);
        Mockito.verify(template,Mockito.times(1)).query(anyString(), any(StatementRowMapper.class),anyVararg());
    } */
}
